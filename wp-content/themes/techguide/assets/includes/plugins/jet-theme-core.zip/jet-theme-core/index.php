<?php
/**
 * Silence is golden.
 */