<?php
/**
 * Review title
 */
$this->__html( $this->__get_review_data(), 'review_title', '<h4 class="jet-review__title">%s</h4>' );
