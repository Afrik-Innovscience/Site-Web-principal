# JetReviews

## Changelog

### 1.1.0
- ADD: Structured Data markup;
- FIX: Conflicts with PHP 7.2.
